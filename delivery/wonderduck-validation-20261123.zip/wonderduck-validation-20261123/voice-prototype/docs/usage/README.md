# 使用文档

本目录提供设备使用说明。

- [TF 卡镜像备份](tf-image-backup.md)：离线制作带首次启动自动扩容的小镜像。
- [PS3 手柄连接](ps3-controller.md)：连接新机器与自动登记输入设备。
- [语音交互原型](voice-interaction.md)：本地唤醒词、白名单指令、音频自检和运行方式。
