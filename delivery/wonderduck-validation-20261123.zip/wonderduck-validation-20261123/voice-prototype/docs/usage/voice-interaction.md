# 语音交互原型

当前实现是本机离线语音指令原型，不会把录音发送到云端，也不默认安装为开机服务。

## 前置条件

- 机器鸭当前镜像能识别 `aic3104` 录音/播放声卡；源码默认录音设备为 `plughw:aic3104,0`。
- 安装 `alsa-utils`、`espeak-ng`，并准备支持中文的多语言 Whisper 模型及 `whisper-cli`。模型不随源码发布。
- `robotd` 正常运行；启动脚本的用户需能访问 `/run/robotd.sock` 和 ALSA 声卡。
- 若 `/etc/robot/robotd.toml` 中 `[audio].pet_detect = true`，先关闭它。采集设备为单客户端，宠物识别和语音识别不能同时独占打开麦克风。

建议先在机器鸭上运行音频自检。录音数据只存放在临时目录，进程退出后删除：

```sh
python3 scripts/audio-diagnostic.py --seconds 4 --play-tone
```

若设备名称不同，可显式覆盖：

```sh
python3 scripts/audio-diagnostic.py --device plughw:aic3104,0 --seconds 4 --play-tone
```

有效录音会报告峰值、RMS 和削波比例；测试音播放后需人工确认扬声器有声音。

## 运行

设置本机 ASR 模型路径，再启动持续监听：

```sh
export WONDERDUCK_ASR_MODEL=/var/lib/robot/voice/models/ggml-tiny.bin
python3 scripts/voice_assistant.py
```

默认每次录制 4 秒并离线识别，唤醒词是“小鸭小鸭”。可通过 `WONDERDUCK_VOICE_CAPTURE_SECONDS`、`WONDERDUCK_ASR_THREADS`、`WONDERDUCK_WAKE_WORDS` 调整窗口、CPU 线程数和唤醒词。录音结束后立即删除临时 WAV。

只录一段进行桌面/机旁验证时，可不说唤醒词：

```sh
python3 scripts/voice_assistant.py --once
```

内置指令：问候、小鸭叫声、帮助，以及无需唤醒词的“停止/停下/别动”。“停止”通过 `robot.stop` 发送。其他运动技能默认不开放；需要时通过 JSON 映射到机器人已安装的技能，并且每次执行都要求在 20 秒内口头确认：

```sh
export WONDERDUCK_VOICE_SKILLS='{"挥手":"wave"}'
python3 scripts/voice_assistant.py
```

机器人会先确认技能确实已安装，再要求说“确认执行”；说“取消”或超时不会动作。若 Studio 或其他控制端正在控制机器人，`robotd` 会拒绝该动作。

可用环境变量：

| 变量 | 默认值 | 用途 |
| --- | --- | --- |
| `WONDERDUCK_ASR_MODEL` | `/var/lib/robot/voice/models/ggml-tiny.bin` | 多语言 Whisper ggml 模型 |
| `WONDERDUCK_ASR_BIN` | `whisper-cli` | Whisper.cpp CLI 路径 |
| `WONDERDUCK_ASR_THREADS` | `2` | ASR CPU 线程数，允许 1-4 |
| `WONDERDUCK_TTS_BIN` | `espeak-ng` | 离线 TTS 程序 |
| `WONDERDUCK_TTS_VOICE` | `zh` | 本机中文语音 |
| `WONDERDUCK_AUDIO_DEVICE` | `robotd.toml` 的 `audio.device` | 扬声器 ALSA 设备 |
| `WONDERDUCK_CAPTURE_DEVICE` | `audio.device` 补 `,0` | 麦克风 ALSA 设备 |
| `WONDERDUCK_ROBOT_SOCKET` | `/run/robotd.sock` | robotd IPC socket |
| `WONDERDUCK_VOICE_SKILLS` | 空映射 | 需二次确认的口令到技能 JSON 映射 |

## 限制

- 固定 4 秒录音窗口加批量识别，不是低延迟流式对话；先用在短指令，真机测试后再调整。
- `whisper-cli` 和多语言模型需单独安装；RK3566 上的识别延迟、温升和与步态推理并行时的资源占用尚未实测。
- eSpeak NG 是离线演示音色，中文自然度有限。它通过项目现有的 `audio-output.py` 播放，避免绕过功放控制。
- 默认无自由聊天模型，文本不会被映射成任意 RPC、命令行或舵机目标。技能动作必须显式配置、设备确认和用户二次口头确认。

## 测试

不需要麦克风、音箱、机器人或 ASR 模型：

```sh
python3 -m unittest discover -s tests -p 'test_voice_assistant.py' -v
```
