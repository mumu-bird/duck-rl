from pathlib import Path
import sys
import tempfile
import unittest
import wave


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import voice_assistant as voice


class FakeRobot:
    def __init__(self):
        self.calls = []

    def call(self, method, params=None):
        self.calls.append((method, params))
        if method == "robot.skills":
            return {"skills": [{"name": "wave"}], "built_in": []}
        return {"accepted": True}

    def skill_names(self):
        self.call("robot.skills")
        return {"wave"}


class FakeSpeaker:
    def __init__(self):
        self.lines = []

    def speak(self, text):
        self.lines.append(text)


class VoiceAssistantTests(unittest.TestCase):
    def setUp(self):
        self.robot = FakeRobot()
        self.speaker = FakeSpeaker()
        self.assistant = voice.VoiceAssistant(
            self.robot, self.speaker, {"挥手": "wave"},
        )

    def test_stop_is_accepted_without_wake_word(self):
        result = self.assistant.process_text("请停下！", now=10)
        self.assertEqual(result, "stop")
        self.assertEqual(self.robot.calls[0][0], "robot.stop")

    def test_unwoken_non_stop_is_ignored(self):
        result = self.assistant.process_text("你好", now=10)
        self.assertEqual(result, "ignored")
        self.assertEqual(self.robot.calls, [])
        self.assertEqual(self.speaker.lines, [])

    def test_wake_and_greeting_calls_sound_and_speaks(self):
        result = self.assistant.process_text("小鸭小鸭，你好", now=10)
        self.assertEqual(result, "greet")
        self.assertEqual(self.robot.calls[0], ("robot.sound", {"tag": "greet"}))
        self.assertIn("你好", self.speaker.lines[-1])

    def test_skill_requires_spoken_confirmation(self):
        result = self.assistant.process_text("小鸭小鸭，挥手", now=10)
        self.assertEqual(result, "confirm-required")
        self.assertFalse(any(method == "robot.do" for method, _ in self.robot.calls))

        result = self.assistant.process_text("确认执行", now=11)
        self.assertEqual(result, "skill")
        self.assertIn(("robot.do", {"skill": "wave"}), self.robot.calls)

    def test_skill_can_be_cancelled(self):
        self.assistant.process_text("小鸭小鸭，挥手", now=10)
        result = self.assistant.process_text("取消", now=11)
        self.assertEqual(result, "cancel")
        self.assertFalse(any(method == "robot.do" for method, _ in self.robot.calls))

    def test_skill_confirmation_expires(self):
        self.assistant.process_text("小鸭小鸭，挥手", now=10)
        result = self.assistant.process_text("确认", now=31)
        self.assertEqual(result, "ignored")
        self.assertFalse(any(method == "robot.do" for method, _ in self.robot.calls))

    def test_wake_only_arms_following_utterance(self):
        result = self.assistant.process_text("小鸭小鸭", now=10)
        self.assertEqual(result, "awake")
        result = self.assistant.process_text("你好", now=12)
        self.assertEqual(result, "greet")

    def test_unknown_skill_is_not_sent(self):
        self.assistant.skill_aliases = {"舞蹈": "not-installed"}
        result = self.assistant.process_text("小鸭小鸭，舞蹈", now=10)
        self.assertEqual(result, "unavailable-skill")
        self.assertFalse(any(method == "robot.do" for method, _ in self.robot.calls))

    def test_capture_device_appends_only_missing_subdevice(self):
        self.assertEqual(voice.capture_device_name("plughw:aic3104"), "plughw:aic3104,0")
        self.assertEqual(voice.capture_device_name("plughw:aic3104,0"), "plughw:aic3104,0")

    def test_wake_word_and_punctuation_normalization(self):
        found, text = voice.strip_wake_word("小鸭小鸭，向前走。", ("小鸭小鸭",))
        self.assertTrue(found)
        self.assertEqual(text, "向前走")

    def test_audio_metrics_report_silence(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "silence.wav"
            with wave.open(str(path), "wb") as output:
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(16000)
                output.writeframes(b"\0\0" * 16000)
            metrics = voice.read_wave_metrics(path)
        self.assertEqual(metrics["peak"], 0)
        self.assertFalse(voice.has_audio(metrics))

    def test_skill_mapping_requires_json_and_valid_names(self):
        self.assertEqual(voice.parse_skill_aliases('{"挥手":"wave"}'), {"挥手": "wave"})
        with self.assertRaises(voice.VoiceError):
            voice.parse_skill_aliases('["wave"]')
        with self.assertRaises(voice.VoiceError):
            voice.parse_skill_aliases('{"挥手":"wave; rm -rf /"}')


if __name__ == "__main__":
    unittest.main()
