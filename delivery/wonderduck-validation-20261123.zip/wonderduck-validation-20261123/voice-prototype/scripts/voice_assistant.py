#!/usr/bin/env python3
"""Offline, wake-word voice commands for WonderDuck."""

from __future__ import annotations

import argparse
from array import array
from dataclasses import dataclass
import json
import math
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import tomllib
import unicodedata
import wave


ROOT = Path(__file__).resolve().parent.parent
DEFAULT_AUDIO_CONFIG = Path("/etc/robot/robotd.toml")
DEFAULT_ROBOT_SOCKET = Path("/run/robotd.sock")
DEFAULT_MODEL = Path("/var/lib/robot/voice/models/ggml-tiny.bin")
DEFAULT_AUDIO_OUTPUT = ROOT / "scripts" / "audio-output.py"
MAX_IPC_LINE = 1024 * 1024
PENDING_SKILL_SECONDS = 20.0
WAKE_HOLD_SECONDS = 15.0
STOP_PHRASES = ("停止", "停下", "别动", "停一停")


class VoiceError(RuntimeError):
    pass


@dataclass(frozen=True)
class AudioSettings:
    playback_device: str
    capture_device: str
    enabled: bool
    pet_detect: bool


def capture_device_name(device: str) -> str:
    device = device.strip()
    if not device:
        raise VoiceError("ALSA 音频设备名称为空")
    return device if "," in device else f"{device},0"


def load_audio_settings(path: Path | str | None = None) -> AudioSettings:
    config_path = Path(path or os.environ.get("WONDERDUCK_AUDIO_CONFIG", DEFAULT_AUDIO_CONFIG))
    config = {}
    if config_path.exists():
        try:
            with config_path.open("rb") as source:
                config = tomllib.load(source)
        except (OSError, tomllib.TOMLDecodeError) as error:
            raise VoiceError(f"无法读取音频配置 {config_path}: {error}") from error

    audio = config.get("audio", {})
    playback_device = os.environ.get("WONDERDUCK_AUDIO_DEVICE", audio.get("device", "plughw:aic3104"))
    capture_device = os.environ.get("WONDERDUCK_CAPTURE_DEVICE", capture_device_name(playback_device))
    if not isinstance(playback_device, str) or not isinstance(capture_device, str):
        raise VoiceError("音频设备配置必须是字符串")
    return AudioSettings(
        playback_device=playback_device,
        capture_device=capture_device,
        enabled=audio.get("enabled", True) is not False,
        pet_detect=audio.get("pet_detect", False) is True,
    )


def read_wave_metrics(path: Path | str) -> dict[str, float | int]:
    with wave.open(str(path), "rb") as source:
        channels = source.getnchannels()
        width = source.getsampwidth()
        rate = source.getframerate()
        frames = source.getnframes()
        if channels != 1 or width != 2 or rate != 16000:
            raise VoiceError("录音格式异常，期望 16 kHz、单声道、16-bit PCM")
        samples = array("h")
        samples.frombytes(source.readframes(frames))

    if sys.byteorder != "little":
        samples.byteswap()
    if not samples:
        raise VoiceError("录音没有 PCM 数据")

    peak = max(abs(sample) for sample in samples)
    square_sum = sum(sample * sample for sample in samples)
    rms = math.sqrt(square_sum / len(samples)) / 32768.0
    clipped = sum(abs(sample) >= 32700 for sample in samples)
    return {
        "frames": len(samples),
        "duration_seconds": len(samples) / rate,
        "peak": peak,
        "rms": rms,
        "rms_dbfs": 20.0 * math.log10(rms) if rms else -120.0,
        "clipped_fraction": clipped / len(samples),
    }


def has_audio(metrics: dict[str, float | int]) -> bool:
    return int(metrics["peak"]) >= 64 and float(metrics["rms"]) >= 0.0005


def normalize_text(text: str) -> str:
    normalized = unicodedata.normalize("NFKC", text).lower()
    return "".join(char for char in normalized if not char.isspace() and unicodedata.category(char)[0] not in "PZ")


def parse_skill_aliases(raw: str | None) -> dict[str, str]:
    if not raw:
        return {}
    try:
        values = json.loads(raw)
    except json.JSONDecodeError as error:
        raise VoiceError("WONDERDUCK_VOICE_SKILLS 必须是 JSON 对象") from error
    if not isinstance(values, dict):
        raise VoiceError("WONDERDUCK_VOICE_SKILLS 必须是 JSON 对象")

    result = {}
    for phrase, skill in values.items():
        if not isinstance(phrase, str) or not isinstance(skill, str):
            raise VoiceError("技能映射的键和值都必须是字符串")
        alias = normalize_text(phrase)
        if not alias or len(alias) > 32 or not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", skill):
            raise VoiceError(f"无效的语音技能映射: {phrase!r}")
        result[alias] = skill
    return result


def strip_wake_word(text: str, wake_words: tuple[str, ...]) -> tuple[bool, str]:
    normalized = normalize_text(text)
    for word in sorted((normalize_text(item) for item in wake_words if item), key=len, reverse=True):
        if normalized.startswith(word):
            return True, normalized[len(word):]
    return False, normalized


def classify_command(text: str, skill_aliases: dict[str, str]) -> tuple[str, str | None, str | None]:
    normalized = normalize_text(text)
    if any(phrase in normalized for phrase in STOP_PHRASES):
        return "stop", None, None
    if any(phrase in normalized for phrase in ("你好", "嗨", "早上好", "晚上好", "你是谁", "介绍一下")):
        return "greet", None, None
    if any(phrase in normalized for phrase in ("叫一声", "嘎一声", "唱一声")):
        return "quack", None, None
    if "帮助" in normalized or "会做什么" in normalized:
        return "help", None, None
    for alias, skill in sorted(skill_aliases.items(), key=lambda item: len(item[0]), reverse=True):
        if alias in normalized:
            return "skill", alias, skill
    return "unknown", None, None


class RobotClient:
    def __init__(self, socket_path: Path | str = DEFAULT_ROBOT_SOCKET, timeout: float = 2.0):
        self.socket_path = str(socket_path)
        self.timeout = timeout

    def call(self, method: str, params: dict | None = None) -> dict:
        request = {"jsonrpc": "2.0", "id": 1, "method": method}
        if params is not None:
            request["params"] = params
        payload = json.dumps(request, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n"

        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
                connection.settimeout(self.timeout)
                connection.connect(self.socket_path)
                connection.sendall(payload)
                with connection.makefile("rb") as reader:
                    line = reader.readline(MAX_IPC_LINE + 1)
        except OSError as error:
            raise VoiceError(f"无法连接 robotd: {error}") from error

        if not line or len(line) > MAX_IPC_LINE:
            raise VoiceError("robotd 返回了空响应或过长响应")
        try:
            response = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError) as error:
            raise VoiceError("robotd 返回了无效 JSON") from error
        if response.get("id") != 1:
            raise VoiceError("robotd 响应 ID 不匹配")
        if response.get("error"):
            error = response["error"]
            raise VoiceError(str(error.get("message", error)))

        result = response.get("result")
        if isinstance(result, dict) and result.get("accepted") is False:
            reason = result.get("reason") or result.get("message") or "动作被机器人拒绝"
            raise VoiceError(str(reason))
        return result if isinstance(result, dict) else {}

    def skill_names(self) -> set[str]:
        result = self.call("robot.skills")
        names = {item.get("name") for item in result.get("skills", []) if isinstance(item, dict)}
        names.update(name for name in result.get("built_in", []) if isinstance(name, str))
        return {name for name in names if isinstance(name, str)}


class Speaker:
    def __init__(self, settings: AudioSettings):
        self.settings = settings
        self.tts = os.environ.get("WONDERDUCK_TTS_BIN", "espeak-ng")
        self.voice = os.environ.get("WONDERDUCK_TTS_VOICE", "zh")
        self.audio_output = Path(os.environ.get("WONDERDUCK_AUDIO_OUTPUT", DEFAULT_AUDIO_OUTPUT))

    def speak(self, text: str) -> None:
        with tempfile.TemporaryDirectory(prefix="wonderduck-voice-") as directory:
            wav_path = Path(directory) / "reply.wav"
            try:
                synth = subprocess.run(
                    [self.tts, "-v", self.voice, "-s", "155", "-w", str(wav_path), text],
                    capture_output=True,
                    text=True,
                    timeout=20,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired) as error:
                raise VoiceError(f"中文语音合成失败: {error}") from error
            if synth.returncode != 0 or not wav_path.is_file():
                detail = synth.stderr.strip() or "未生成 WAV"
                raise VoiceError(f"中文语音合成失败: {detail}")

            try:
                playback = subprocess.run(
                    [sys.executable, str(self.audio_output), "-D", self.settings.playback_device,
                     "-q", str(wav_path)],
                    capture_output=True,
                    text=True,
                    timeout=30,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired) as error:
                raise VoiceError(f"扬声器播放失败: {error}") from error
            if playback.returncode != 0:
                detail = playback.stderr.strip() or "audio-output.py 返回错误"
                raise VoiceError(f"扬声器播放失败: {detail}")


class WhisperRecognizer:
    def __init__(self, model: Path | str, binary: str = "whisper-cli", threads: int = 2):
        self.model = Path(model)
        self.binary = binary
        self.threads = max(1, min(threads, 4))

    def transcribe(self, wav_path: Path | str) -> str:
        if not self.model.is_file():
            raise VoiceError(f"Whisper 模型不存在: {self.model}")
        if shutil.which(self.binary) is None and not Path(self.binary).is_file():
            raise VoiceError(f"找不到语音识别程序: {self.binary}")

        command = [
            self.binary, "-m", str(self.model), "-f", str(wav_path), "-l", "zh",
            "-nt", "-np", "-sns", "-nf", "-t", str(self.threads),
        ]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=45, check=False)
        except (OSError, subprocess.TimeoutExpired) as error:
            raise VoiceError(f"语音识别失败: {error}") from error
        if result.returncode != 0:
            detail = result.stderr.strip() or "whisper-cli 返回错误"
            raise VoiceError(f"语音识别失败: {detail}")
        return result.stdout.strip()


class VoiceAssistant:
    def __init__(self, robot: RobotClient, speaker: Speaker, skill_aliases: dict[str, str],
                 wake_words: tuple[str, ...] = ("小鸭小鸭",)):
        self.robot = robot
        self.speaker = speaker
        self.skill_aliases = skill_aliases
        self.wake_words = wake_words
        self.awake_until = 0.0
        self.pending_skill: tuple[str, str, float] | None = None

    def _say(self, text: str) -> None:
        print(f"小鸭: {text}", flush=True)
        try:
            self.speaker.speak(text)
        except VoiceError as error:
            print(f"语音播报失败: {error}", file=sys.stderr, flush=True)

    def process_text(self, text: str, require_wake: bool = True, now: float | None = None) -> str:
        now = time.monotonic() if now is None else now
        normalized = normalize_text(text)
        if not normalized:
            return "empty"

        kind, _, _ = classify_command(normalized, {})
        if kind == "stop":
            self.pending_skill = None
            self.awake_until = 0.0
            try:
                self.robot.call("robot.stop")
            except VoiceError as error:
                self._say("停止指令没有发送成功，请立即手动停止机器人。")
                print(f"停止指令失败: {error}", file=sys.stderr, flush=True)
                return "error"
            self._say("好的，已发送停止指令。")
            return "stop"

        if self.pending_skill:
            label, skill, deadline = self.pending_skill
            if now > deadline:
                self.pending_skill = None
            elif "取消" in normalized:
                self.pending_skill = None
                self._say("已取消。")
                return "cancel"
            elif "确认" in normalized:
                self.pending_skill = None
                return self._run_skill(label, skill)
            else:
                self._say("请说确认执行，或说取消。")
                return "confirm-pending"

        if require_wake:
            if now < self.awake_until:
                command_text = normalized
            else:
                found, command_text = strip_wake_word(normalized, self.wake_words)
                if not found:
                    return "ignored"
                if not command_text:
                    self.awake_until = now + WAKE_HOLD_SECONDS
                    self._say("我在听，请说吧。")
                    return "awake"
        else:
            _, command_text = strip_wake_word(normalized, self.wake_words)

        self.awake_until = 0.0
        kind, label, skill = classify_command(command_text, self.skill_aliases)
        if kind == "greet":
            try:
                self.robot.call("robot.sound", {"tag": "greet"})
            except VoiceError as error:
                print(f"鸭叫音效不可用: {error}", file=sys.stderr, flush=True)
            self._say("你好，我是机器鸭。")
            return "greet"
        if kind == "quack":
            try:
                self.robot.call("robot.sound", {"tag": "greet"})
            except VoiceError as error:
                self._say("我现在没法发出声音。")
                print(f"鸭叫音效不可用: {error}", file=sys.stderr, flush=True)
                return "error"
            self._say("嘎！")
            return "quack"
        if kind == "help":
            self._say("你可以问候我、让我叫一声，或说停下。配置动作后，也可以让我执行动作。")
            return "help"
        if kind == "skill" and label and skill:
            try:
                available = self.robot.skill_names()
            except VoiceError as error:
                self._say("我暂时读不到可用动作。")
                print(f"读取机器人动作失败: {error}", file=sys.stderr, flush=True)
                return "error"
            if skill not in available:
                self._say("这台机器人没有配置这个动作。")
                return "unavailable-skill"
            self.pending_skill = (label, skill, now + PENDING_SKILL_SECONDS)
            self._say(f"准备执行{label}动作，请在二十秒内说确认执行，或说取消。")
            return "confirm-required"

        self._say("我还不会这个指令。你可以说你好、叫一声，或停下。")
        return "unknown"

    def _run_skill(self, label: str, skill: str) -> str:
        try:
            available = self.robot.skill_names()
            if skill not in available:
                self._say("这个动作当前不可用，没有执行。")
                return "unavailable-skill"
            self.robot.call("robot.do", {"skill": skill})
        except VoiceError as error:
            self._say("动作没有执行，可能有其他控制端正在操作机器人。")
            print(f"动作执行失败: {error}", file=sys.stderr, flush=True)
            return "error"
        self._say(f"开始执行{label}。")
        return "skill"


def capture_wav(path: Path, device: str, seconds: int) -> None:
    command = [
        "arecord", "-q", "-D", device, "-f", "S16_LE", "-r", "16000", "-c", "1",
        "-d", str(seconds), "-t", "wav", str(path),
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True,
                                timeout=seconds + 10, check=False)
    except (OSError, subprocess.TimeoutExpired) as error:
        raise VoiceError(f"麦克风录音失败: {error}") from error
    if result.returncode != 0 or not path.is_file():
        detail = result.stderr.strip() or "arecord 返回错误"
        raise VoiceError(f"麦克风录音失败: {detail}")


def run(args: argparse.Namespace) -> int:
    settings = load_audio_settings(args.config)
    if not settings.enabled:
        raise VoiceError("robotd.toml 中 audio.enabled=false，语音交互已停止")
    if settings.pet_detect:
        raise VoiceError("audio.pet_detect=true 正占用单客户端麦克风；运行语音交互前请关闭该功能")
    if not shutil.which("arecord"):
        raise VoiceError("找不到 arecord，请安装 alsa-utils")
    if not Path(DEFAULT_AUDIO_OUTPUT).is_file():
        raise VoiceError(f"找不到扬声器适配器: {DEFAULT_AUDIO_OUTPUT}")

    model = args.model or os.environ.get("WONDERDUCK_ASR_MODEL", str(DEFAULT_MODEL))
    binary = os.environ.get("WONDERDUCK_ASR_BIN", "whisper-cli")
    recognizer = WhisperRecognizer(model, binary, args.threads)
    robot = RobotClient(args.socket)
    speaker = Speaker(settings)
    skills = parse_skill_aliases(os.environ.get("WONDERDUCK_VOICE_SKILLS"))
    wake_words = tuple(filter(None, os.environ.get("WONDERDUCK_WAKE_WORDS", "小鸭小鸭").split(",")))
    assistant = VoiceAssistant(robot, speaker, skills, wake_words)

    def one_turn(require_wake: bool) -> None:
        with tempfile.TemporaryDirectory(prefix="wonderduck-voice-") as directory:
            wav_path = Path(directory) / "utterance.wav"
            capture_wav(wav_path, settings.capture_device, args.seconds)
            metrics = read_wave_metrics(wav_path)
            if not has_audio(metrics):
                print("未检测到有效语音片段。", flush=True)
                return
            started = time.monotonic()
            transcript = recognizer.transcribe(wav_path)
            elapsed = time.monotonic() - started
            print(f"识别 ({elapsed:.1f}s): {transcript or '[无文本]'}", flush=True)
            assistant.process_text(transcript, require_wake=require_wake)

    if args.once:
        one_turn(require_wake=False)
        return 0

    print(f"语音交互已启动，唤醒词：{'、'.join(wake_words)}；按 Ctrl+C 退出。", flush=True)
    while True:
        try:
            one_turn(require_wake=True)
        except VoiceError as error:
            print(f"语音交互暂时不可用: {error}", file=sys.stderr, flush=True)
            time.sleep(2)


def main() -> int:
    parser = argparse.ArgumentParser(description="WonderDuck 本地语音指令原型")
    parser.add_argument("--once", action="store_true", help="录一段并处理，不要求唤醒词")
    parser.add_argument("--config", type=Path, help="robotd TOML 配置文件")
    parser.add_argument("--socket", type=Path, default=Path(os.environ.get("WONDERDUCK_ROBOT_SOCKET", DEFAULT_ROBOT_SOCKET)))
    parser.add_argument("--model", type=Path, help="Whisper 多语言 ggml 模型文件")
    parser.add_argument("--seconds", type=int, default=int(os.environ.get("WONDERDUCK_VOICE_CAPTURE_SECONDS", "4")))
    parser.add_argument("--threads", type=int, default=int(os.environ.get("WONDERDUCK_ASR_THREADS", "2")))
    args = parser.parse_args()
    if not 2 <= args.seconds <= 10:
        parser.error("--seconds 必须在 2 到 10 秒之间")
    if not 1 <= args.threads <= 4:
        parser.error("--threads 必须在 1 到 4 之间")
    try:
        return run(args)
    except VoiceError as error:
        print(f"错误: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
