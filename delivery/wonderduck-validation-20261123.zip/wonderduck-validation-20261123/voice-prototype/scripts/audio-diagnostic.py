#!/usr/bin/env python3
"""Check WonderDuck ALSA capture level and optionally play a test tone."""

import argparse
import math
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import wave

from voice_assistant import VoiceError, capture_device_name, load_audio_settings, read_wave_metrics


ROOT = Path(__file__).resolve().parent.parent
AUDIO_OUTPUT = ROOT / "scripts" / "audio-output.py"
RATE = 16000


def make_tone(path: Path, seconds: float = 0.5, frequency: float = 660.0) -> None:
    count = int(RATE * seconds)
    frames = bytearray()
    for index in range(count):
        value = int(32767 * 0.15 * math.sin(2 * math.pi * frequency * index / RATE))
        frames.extend(struct.pack("<h", value))
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(RATE)
        output.writeframes(frames)


def run() -> int:
    parser = argparse.ArgumentParser(description="机器鸭麦克风与扬声器自检")
    parser.add_argument("--config", type=Path, help="robotd TOML 配置文件")
    parser.add_argument("--device", help="覆盖 ALSA 录音设备")
    parser.add_argument("--seconds", type=int, default=4)
    parser.add_argument("--play-tone", action="store_true", help="录音后经机器人扬声器播放短测试音")
    parser.add_argument("--list-only", action="store_true", help="只列出 ALSA 录音设备")
    args = parser.parse_args()
    if not 1 <= args.seconds <= 15:
        parser.error("--seconds 必须在 1 到 15 秒之间")

    if not shutil.which("arecord"):
        print("错误: 找不到 arecord，请安装 alsa-utils。", file=sys.stderr)
        return 1
    devices = subprocess.run(["arecord", "-l"], capture_output=True, text=True, check=False)
    print("ALSA 录音设备:")
    print(devices.stdout.strip() or devices.stderr.strip() or "(未列出设备)")
    if devices.returncode != 0:
        return 1
    if args.list_only:
        return 0

    try:
        settings = load_audio_settings(args.config)
        capture_device = capture_device_name(args.device) if args.device else settings.capture_device
        if settings.pet_detect:
            print("警告: audio.pet_detect=true，采集设备可能正被占用。", file=sys.stderr)
        print(f"录音设备: {capture_device}; 格式: 16 kHz mono S16_LE; 时长: {args.seconds}s")

        with tempfile.TemporaryDirectory(prefix="wonderduck-audio-check-") as directory:
            recording = Path(directory) / "mic.wav"
            command = ["arecord", "-q", "-D", capture_device, "-f", "S16_LE", "-r",
                       str(RATE), "-c", "1", "-d", str(args.seconds), "-t", "wav", str(recording)]
            captured = subprocess.run(command, capture_output=True, text=True,
                                      timeout=args.seconds + 10, check=False)
            if captured.returncode != 0 or not recording.is_file():
                detail = captured.stderr.strip() or "arecord 返回错误"
                raise VoiceError(f"麦克风录音失败: {detail}")

            metrics = read_wave_metrics(recording)
            print("录音结果: {:.2f}s, 峰值={}, RMS={:.1f} dBFS, 削波={:.3f}%".format(
                metrics["duration_seconds"], metrics["peak"], metrics["rms_dbfs"],
                float(metrics["clipped_fraction"]) * 100.0,
            ))
            if int(metrics["peak"]) < 64 or float(metrics["rms"]) < 0.0005:
                print("结果: 输入过低或静音。检查麦克风、codec、amixer capture 路由与环境距离。")
                return 2
            if float(metrics["clipped_fraction"]) > 0.001:
                print("警告: 输入有明显削波，可降低 PGA Capture Volume。")
            else:
                print("结果: 检测到有效麦克风输入。")

            if args.play_tone:
                if not AUDIO_OUTPUT.is_file():
                    raise VoiceError(f"找不到扬声器适配器: {AUDIO_OUTPUT}")
                tone = Path(directory) / "tone.wav"
                make_tone(tone)
                played = subprocess.run(
                    [sys.executable, str(AUDIO_OUTPUT), "-D", settings.playback_device, "-q", str(tone)],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    check=False,
                )
                if played.returncode != 0:
                    detail = played.stderr.strip() or "audio-output.py 返回错误"
                    raise VoiceError(f"扬声器测试失败: {detail}")
                print("已播放 660 Hz 测试音；请确认能从机器鸭扬声器听到。")
    except (VoiceError, OSError, subprocess.SubprocessError) as error:
        print(f"错误: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(run())
