#!/usr/bin/env python3
"""Verify bundled files locally; never connects to a device."""
from pathlib import Path
import hashlib
import sys

root = Path(__file__).resolve().parent
failures = []
checked = 0
for line in (root / "CHECKSUMS.sha256").read_text(encoding="utf-8").splitlines():
    expected, name = line.split("  ", 1)
    target = (root / name).resolve()
    if root not in target.parents or not target.is_file():
        failures.append(name + ": missing or invalid path")
        continue
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    checked += 1
    if actual != expected:
        failures.append(name + ": checksum mismatch")
if failures:
    print("FILES_FAILED\n" + "\n".join(failures))
    sys.exit(1)
print("FILES_OK: {} files verified; no device was contacted.".format(checked))
